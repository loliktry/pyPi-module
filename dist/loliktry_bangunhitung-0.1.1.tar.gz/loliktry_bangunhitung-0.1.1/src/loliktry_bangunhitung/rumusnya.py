import math
# Rumus bangun

def luas_persegipanjang(a, b):
    return a * b
def luas_lingkaran(radius):
    return math.pi * radius ** 2

def keliling_lingkaran(radius):
    return 2 * math.pi * radius


# Rumusa hitungan
def tambah(a, b):
    return a + b

def kurang(a, b):
    return a - b

def kali(a, b):
    return a * b

def bagi(a, b):
    return a / b

