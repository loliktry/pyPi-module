import math
# Rumus bangun

class Rumusnya:
    def __init__(self):
        return None

    def luas_persegipanjang(self, a, b):
        return a * b

    def luas_lingkaran(self, radius):
        return math.pi * radius ** 2

    def keliling_lingkaran(self, radius):
        return 2 * math.pi * radius

    # Rumusa hitungan
    def tambah(self, a, b):
        return a + b

    def kurang(self, a, b):
        return a - b

    def kali(self, a, b):
        return a * b

    def bagi(self, a, b):
        return a / b

