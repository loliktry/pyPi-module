import math

def luas_lingkaran(radius):
    return math.pi * radius ** 2

def keliling_lingkaran(radius):
    return 2 * math.pi * radius

if __name__ == '__main__':
    print("data baru")